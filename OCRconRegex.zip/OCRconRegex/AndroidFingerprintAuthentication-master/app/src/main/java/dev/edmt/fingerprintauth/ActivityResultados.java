package dev.edmt.fingerprintauth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.regex.*;


public class ActivityResultados extends AppCompatActivity {
    String texto;
    TextView lblresult;
    TextView lblencontrado;
    ArrayList<String>encontrados = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);
        Bundle bundle = getIntent().getExtras();
        texto = bundle.getString("texto");
        lblencontrado =  (TextView)findViewById(R.id.lblencontrado);
        lblresult = (TextView)findViewById(R.id.lblresultados);
        lblresult.setText("el texto detectado fue: " + texto);
    }
    public void Buscar(View view)
    {
        String detectadomin = texto.toLowerCase().trim();
        detectadomin = detectadomin.replaceAll(" ","");
        encontrar("ph:{1}+[0-9]{1,5}+,{1}+[0-9]{1,5}",detectadomin);
        encontrar("nahco3:{1}+[0-9]{1,10}+,{1}+[0-9]{1,5}",detectadomin);
        encontrar("po2:{1}+[0-9]{1,5}+,{1}+[0-9]{1,5}",detectadomin);
        encontrar("pco2:{1}+[0-9]{1,5}+,{1}+[0-9]{1,5}",detectadomin);

    }
    public void encontrar(String regex, String TextoaUsar)
    {
        Pattern checkRegex = Pattern.compile(regex);
        Matcher regexMatcher = checkRegex.matcher(TextoaUsar);

        while (regexMatcher.find()){

            if (regexMatcher.group().length() != 0)
            {
                Toast.makeText(this, regexMatcher.group().trim(), Toast.LENGTH_SHORT).show();
            }

        }

    }
    public void Volver(View view)
    {
        Intent intent = new Intent(this, OCR.class);
        startActivity(intent);
    }
}
