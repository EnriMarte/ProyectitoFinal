package website.copyandpaste.afb02textviews;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    //this is MainActivity

    //This is method for creating our app
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //Click on sidebar at "layout"
    //Now we can run our first app!
    //(in next tutorial)
}
