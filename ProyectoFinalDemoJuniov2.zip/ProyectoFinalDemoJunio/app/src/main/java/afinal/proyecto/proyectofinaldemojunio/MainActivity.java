package afinal.proyecto.proyectofinaldemojunio;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import afinal.proyecto.proyectofinaldemojunio.Fragments.fragmentMenuPrincipal;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fm = getFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();

        fragmentMenuPrincipal fragmentPrincipal = new fragmentMenuPrincipal();
        fragmentTransaction.replace(R.id.fragment_container, fragmentPrincipal, "menuPrincipalTag");
        fragmentTransaction.commit();
        //todo: armar vistas detalles (paciente, usuario, credencial y funcion)
        //todo: armar vistas agregar nuevo (usuario, paciente, credencial y funcion)
        //todo: armar vista editar (usuario, paciente, credencial y funcion)
        //todo: terminar diseño menuPrincipal (posiblemente despues del login)
        //todo: armar clase, fragment y vista "login"
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //todo: implementar que guarde la instancia actual antes de cambiar el fragment, para poder volver al fragment anterior en vez de al menu principal
        switch (item.getItemId()) {
            case android.R.id.home:

                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_container, new fragmentMenuPrincipal(), "menuPrincipalTag");
                ft.remove(fm.findFragmentByTag("tabMenuTag"));
                ft.commit();
                ActionBar actionBar = getSupportActionBar();
                if (actionBar != null)
                    actionBar.setDisplayHomeAsUpEnabled(false);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
